import requests
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import requests
import defs
import json
import os


class alpha_vantage_API():

    def __init__(self):
        pass
        
    def get_current_info(self):
        url = "https://alpha-vantage.p.rapidapi.com/query"

        querystring = {"function":"FX_INTRADAY","interval":"60min","to_symbol":"USD","from_symbol":"EUR","datatype":"json","outputsize":"compact"}

        headers = {
            "X-RapidAPI-Key": "6bb7160424mshfa734372be55a63p1c7fafjsna749f923b6c9",
            "X-RapidAPI-Host": "alpha-vantage.p.rapidapi.com"
        }

        self.response = requests.get(url, headers=headers, params=querystring).json()
        self.response_values = self.response['Time Series FX (60min)']
        for val in self.response_values.values():
            print(val['4. close'], )
        

    def get_current_formated_data(self):
        closeings = []
        highs = []
        lows = []
        openings = []

        for data_point in self.response_values.values():
            closeings.append(float(data_point['c']))
            openings.append(float(data_point['o']))
            highs.append(float(data_point['h']))
            lows.append(float(data_point['l']))

        current_data = {"BC": closeings,
                        "BH": highs,
                        "BL": lows,
                        "BO": openings}
        
        current_dataframe = pd.DataFrame(current_data)

        return current_dataframe[::-1]


    def get_values_and_dates(self):
        
        new_data_time = list(self.response_values.keys())

        return new_data_time


# Taken from bluefeversoft
class Oanda_API():

    def __init__(self):
        self.session = requests.Session()


    def make_request(self, url, params={}, added_headers=None, verb='get', data=None, code_ok=200):

        headers = defs.SECURE_HEADER

        if added_headers is not None:   
            for k in added_headers.keys():
                headers[k] = added_headers[k]
                
        try:
            response = None
            if verb == 'post':
                response = self.session.post(url,params=params,headers=headers,data=data)
            elif verb == 'put':
                response = self.session.put(url,params=params,headers=headers,data=data)
            else:
                response = self.session.get(url,params=params,headers=headers,data=data)

            status_code = response.status_code

            if status_code == code_ok:
                json_response = response.json()
                return status_code, json_response
            else:
                return status_code, None   

        except:
            print("ERROR")
            return 400, None  


    def place_trade(self, units):
        url = f" {defs.OANDA_URL}/accounts/{defs.ACCOUNT_ID}/orders"

        print()

        data = {
            "order": {
                "units": units,
                "instrument": "EUR_USD",
                "timeInForce": "FOK",
                "type": "MARKET",
                "positionFill": "DEFAULT"
            }
        }

        status_code, json_code = self.make_request(url, verb="post", data=json.dumps(data), code_ok=201)
        
        return (status_code, json_code)


    def close_trade(self, trade_id):
        url = f"{defs. OANDA_URL}/accounts/{defs.ACCOUNT_ID}/trades/{trade_id}/close"
        status_code, json_data = self.make_request(url, verb = 'post', code_ok=200)

        if status_code != 200:
            return False
        
        return True


    def fetch_candlesticks(self, instrument, candles_count, granularity):

        url = f" {defs.OANDA_URL}/instruments/{instrument}/candles?count={candles_count}&price=M&granularity={granularity}"

        candles = self.make_request(url)

        closeings = []
        highs = []
        lows = []
        openings = []

        for i in range(len(candles[1]['candles'])):
            closeings.append(float(candles[1]['candles'][i]['mid']['c']))
            openings.append(float(candles[1]['candles'][i]['mid']['o']))
            highs.append(float(candles[1]['candles'][i]['mid']['h']))
            lows.append(float(candles[1]['candles'][i]['mid']['l']))

        current_data = {"BC": closeings,
                        "BH": highs,
                        "BL": lows,
                        "BO": openings}
        
        current_dataframe = pd.DataFrame(current_data)

        return current_dataframe




def main():
    oanda = Oanda_API()

    candles = oanda.fetch_candlesticks('EUR_USD', '100', 'H1')

    print(candles)

if __name__ == "__main__":

   main()

